﻿using System;


class Program
{
    static void Main()
    {
        // Girilen sayının basamaklarını diziye atayıp, basamaklarına göre listeleme


        //girilen sayıyı değişkene ata --
        // değişkenin basamaklarını al ve diziye ata --
        // dizinin elemanlarına göre listele --


        Console.Write("Bir sayı giriniz: ");
        int number = Convert.ToInt32(Console.ReadLine()); // sayının değişkene atanması
        int[] digits = new int[20];
        int i = 0;
        while (number > 0)
        {
            digits[i] = number % 10; // sayının basamalarını alma adımları 
            number /= 10;
            i++;
        }
        Console.Write("Girilen sayının basamakları: ");
        for (int j = i - 1; j >= 0; j--) // basamakları düz okuma ile yazdırma
        {
            Console.Write(digits[j] + " ");

        }
        Console.WriteLine();
        //Ayrıca dizinin kaçıncı elemanı yani hangi basamağı temsil ediyor yazdırma adımı
        for (int j = 0; j < i; j++)
        {
            Console.WriteLine($"{digits[j]} sayısı dizinin {j}. elemanıdır.");
        }
        









    }
}