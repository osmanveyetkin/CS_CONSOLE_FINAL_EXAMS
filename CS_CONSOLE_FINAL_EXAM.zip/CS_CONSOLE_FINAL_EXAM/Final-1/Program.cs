﻿using System;
using System.Security.AccessControl;

class Program
{
    static void Main()
    {
        // TAU sayısı, bir sayının bölen sayısına tam bölünmesi durumunda o sayıya TAU sayısı denir.
        Console.Write("Bir sayı giriniz: ");
        int num = Convert.ToInt32(Console.ReadLine()); // girilen sayının değişkene atanması adımı.
        int count = 0; //Bölen  sayısının  saklayan sayaç
        for (int i = 1; i <= num; i++)
        {
            if (num % i == 0)
            {
                count++;
            }
        }
        if (  count!= 0 && num % count == 0)
        {
            Console.WriteLine("Girilen sayı bir TAU sayısıdır.");
        }
        else
        {
            Console.WriteLine("Girilen sayı bir TAU sayısı değildir.");
        }



    }
}