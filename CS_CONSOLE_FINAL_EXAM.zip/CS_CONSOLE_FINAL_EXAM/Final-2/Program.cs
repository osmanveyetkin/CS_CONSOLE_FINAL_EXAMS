﻿using System;

class Program
{
    static void Main()
    {

        // Rasgele 10 elemanlı dizi oluşturup, elemanları toplayıp ortalamasını alıp, ortalamadan büyük olanları yeni diziye aktararak yazdırma

        // rastgele 10 elemanlı dizi -
        // dizideki elemanları topla ortalamasınnı al -
        // büyük olanları yeni diziye aktar --
        // dizileri ve ortalamayı yazdır. --

        int[] arrays = new int[10];
        Random rnd = new Random();
        int sum = 0;
        for (int i = 0; i < arrays.Length; i++)
        {
            arrays[i] = rnd.Next(100); // rastgele sayılar diziye atandı
            sum += arrays[i]; // sayılar toplandı
        }
        int avg = sum / arrays.Length; // ortalama hesplandı
        int[] bigger = new int[arrays.Length];
        int count = 0;
        for (int i = 0; i < arrays.Length; i++)
        {
            if (arrays[i] > avg)
            {
                bigger[count] = arrays[i]; // ortalama üssü elemanları atandı
                count++;
            }
        }
        Console.Write("Rastgele oluşturulan dizi: "); // ana dizinin elemanları yazdırıldı.
        for (int i = 0; i < arrays.Length; i++)
        {
            Console.Write(arrays[i] + " ");
        }
        Console.WriteLine();
        Console.WriteLine();
        // Ortalamayı ve büyükler dizisini yazdırma adımı
        Console.Write("Dizinin Ortalaması: " + avg + " olan dizinin elemanlarından büyük olanların yazdıldığı dizi: ");
        for (int i = 0; i < count; i++)
        {
            Console.Write(bigger[i] + " ");
        }




    }
}
