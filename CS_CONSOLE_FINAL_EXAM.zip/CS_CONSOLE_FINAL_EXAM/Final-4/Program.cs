﻿using System;

class Program
{
    static void Main()
    {
        // 4*4 lük matris oluşturup, esas köşegeni bulma ve toplamını yazdırma


        // 4*4 lük matris rastgele eleman atanacak--
        // esas köşegen bulanacak--
        // matrisi yazdırılacak--
        // esas köşegen yazdırılacak--
        // esas köşegenin toplamı yazdırılacak--

        int[,] matris = new int[4, 4]; // matris oluşturma
        Random rnd = new Random();
        int sum = 0; // köşegeni toplama
        for (int i = 0; i < 4; i++) // satırları oluşturma diyelim
        {
            for (int j = 0; j < 4; j++)
            {
                matris[i, j] = rnd.Next(1, 10);
                if (i == j) // esas köşegebn saptama adımı
                {
                    sum += matris[i, j]; // toplama adımı
                }
            }
        }
        Console.WriteLine("Matris: ");
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Console.Write(matris[i, j] + " "); // matrisi yazdırma adımı
            }
            Console.WriteLine();
        }
        Console.Write("Esas Köşegendeki Elemanlar: ");
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (i == j)
                {
                    Console.Write(matris[i, j] + " "); // esas köşegen yazdırıldı.
                }

            }
        }
        Console.WriteLine("\nEsas Köşegen elemanlarının toplamı: " + sum); // toplamı yazdırma


    }
}
